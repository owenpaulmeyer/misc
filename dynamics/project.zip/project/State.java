public enum State { Open, Closed }
