import LambdaCore
import Lambda

main = do
	let a = nor mane
	print a

