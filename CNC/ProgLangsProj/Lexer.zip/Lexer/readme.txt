CnC 2012
Professor Neal Nelson
Programming Languages Project
Lexer handin
Owen Meyer

To run the Lexer, simply type "java Lexer factorial.cpp" or "java Lexer castimplicit.cpp" from the command line in this directory.
