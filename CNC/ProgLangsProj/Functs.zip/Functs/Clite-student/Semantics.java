import java.util.*;
// Following is the semantics class:
// The meaning M of a Statement is a State
// The meaning M of a Expression is a Value

public class Semantics {

    static State M (Program p) { 
//		TypeMap tm = StaticTypeCheck.typing(p.globals);//prolly dont need
		FuncMap fm = new FuncMap();
		for (Function f : p.functions){
			fm.put(f.id, f);
		}
		State state = new State(fm);
		state.allocate(p.globals);
		Function main = fm.get("main");
		Declarations mainDs = main.params;
		mainDs.addAll(main.locals);
		state.allocate(mainDs);
        M (main.body, state); 
		return state;
    }

  
    static void M (Statement s, State st) {
        if (s instanceof Skip)
			M((Skip)s, st);
		else if (s instanceof Assignment)
			M((Assignment)s, st);
		else if (s instanceof Conditional)
			M((Conditional)s, st);
		else if (s instanceof Loop)
			M((Loop)s, st);
		else if (s instanceof Block)
			M((Block)s, st);
		else if (s instanceof CallStmt)
			M((CallStmt)s, st);
		else if (s instanceof Return)
			M((Return)s, st);
		else {
			System.out.println(s instanceof Skip);
			System.out.println("bad " + s);
			throw new IllegalArgumentException("should never reach here");
		}
    }
	
	static void M (Return r, State state){
		Variable rtrn = new Variable("return");
		state.assign(r.rtrn, M (r.result, state));
	}

    static void M (Skip s, State state) {
		System.out.println("skippy");
    }

	static void M (CallStmt cs, State state) {
		Function f = state.fmap.get(cs.name);
		Declarations ds = new Declarations();
		ds.addAll(f.params);
		ds.addAll(f.locals);
		Variable rtrn = new Variable("return");
		Declaration rt = new VariableDecl(rtrn, f.t);
		ds.add(rt);
		state.allocate(ds);
		for (int i = 0; i < f.params.size(); i++){
			Expression arg = cs.args.get(i);
			Value val = M (arg, state);
			Variable var = ds.get(i).v;
			state.assign(var, val);
		}
		M (f.body, state);
		state.stack.pop();
	}

	static void M (Assignment a, State state) {
		/*if (a.target instanceof ArrayRef){
			ArrayRef ar = (ArrayRef)a.target;
			ArrayValue av = (ArrayValue)state.get((Variable)ar);
			int idx = ((IntValue)M (ar.index(), state)).intValue();
			StaticTypeCheck.check(av.size() > idx,"Array is too small maaan!");
			Value val = (Value)M (a.source, state);
			av.array()[idx] = val;
			return state.onion( (Variable)a.target, av);
		}*/
		state.assign((Variable)a.target, M (a.source, state));
    }
//(Statement s, State st, FuncMap fm)
    static void M (Block b,State state) {
        for (Statement s : b.members){
            M (s, state);
		}
    }
  
    static void M (Conditional c, State state) {
        if (M(c.test, state).boolValue( ))
            M (c.thenbranch, state);
        else
            M (c.elsebranch, state);
    }
  
    static void M (Loop l, State state) {
        if (M (l.test, state).boolValue( )){
			M (l.body, state);
            M(l, state);
		}
    }

    static Value applyBinary (Operator op, Value v1, Value v2) {
        StaticTypeCheck.check( ! v1.isUndef( ) && ! v2.isUndef( ),
               "Breference to undef value");
        if (op.val.equals(Operator.INT_PLUS)) 
            return new IntValue(v1.intValue( ) + v2.intValue( ));
        if (op.val.equals(Operator.INT_MINUS)) 
            return new IntValue(v1.intValue( ) - v2.intValue( ));
        if (op.val.equals(Operator.INT_TIMES)) 
            return new IntValue(v1.intValue( ) * v2.intValue( ));
        if (op.val.equals(Operator.INT_DIV)) 
            return new IntValue(v1.intValue( ) / v2.intValue( ));
		if (op.val.equals(Operator.INT_LT)){
			if (v1.intValue() < v2.intValue() )
				return new BoolValue(true);
			else return new BoolValue(false);
		}
        // student exercise
        throw new IllegalArgumentException("should never reach here");
    } 
    
    static Value applyUnary (Operator op, Value v) {
        StaticTypeCheck.check( ! v.isUndef( ),
               "Ureference to undef value");
        if (op.val.equals(Operator.NOT))
            return new BoolValue(!v.boolValue( ));
        else if (op.val.equals(Operator.INT_NEG))
            return new IntValue(-v.intValue( ));
        else if (op.val.equals(Operator.FLOAT_NEG))
            return new FloatValue(-v.floatValue( ));
        else if (op.val.equals(Operator.I2F))
            return new FloatValue((float)(v.intValue( ))); 
        else if (op.val.equals(Operator.F2I))
            return new IntValue((int)(v.floatValue( )));
        else if (op.val.equals(Operator.C2I))
            return new IntValue((int)(v.charValue( )));
        else if (op.val.equals(Operator.I2C))
            return new CharValue((char)(v.intValue( )));
        throw new IllegalArgumentException("should never reach here");
    } 

    static Value M (Expression e, State state) {
        if (e instanceof Value) 
            return (Value)e;
        if (e instanceof Variable){
			/*if (e instanceof ArrayRef){
				ArrayRef ar = (ArrayRef)e;
				ArrayValue av = (ArrayValue)state.get((Variable)ar);
				int idx = ((IntValue)M (ar.index(), state)).intValue();
				StaticTypeCheck.check(av.size() > idx,"Array is too small maaan!");
				return (Value)av.array()[idx];*/
				return state.valueOf((Variable)e);
			//}
			//else return (Value)(state.get(e));
		}
        if (e instanceof Binary) {
            Binary b = (Binary)e;
            return applyBinary (b.op, M(b.term1, state), M(b.term2, state));
        }
        if (e instanceof Unary) {
            Unary u = (Unary)e;
            return applyUnary(u.op, M(u.term, state));
        }
		if (e instanceof CallExpr) {
			CallExpr ce = (CallExpr)e;
			Function f = state.fmap.get(ce.name);
			Declarations ds = new Declarations();
			ds.addAll(f.params);
			ds.addAll(f.locals);
			Variable rtrn = new Variable("return");
			Declaration rt = new VariableDecl(rtrn, f.t);
			ds.add(rt);
			state.allocate(ds);
			for (int i = 0; i < f.params.size(); i++){
				Expression arg = ce.args.get(i);
				Value val = M (arg, state);
				Variable var = f.params.get(i).v;
				state.assign(var, val);
			}
			M (f.body, state);
			Value returnVal = state.valueOf(rtrn);
			state.stack.pop();
			return returnVal;
		}
        throw new IllegalArgumentException("should never reach here!!");
    }
/*		Function f = state.fmap.get(cs.name);
		Declarations ds = new Declarations();
		ds.addAll(f.params);
		ds.addAll(f.locals);
		Variable rtrn = new Variable("return");
		Declaration rt = new VariableDecl(rtrn, f.t);
		ds.add(rt);
		state.allocate(ds);
		for (int i = 0; i < f.params.size(); i++){
			Expression arg = cs.args.get(i);
			Value val = M (arg, state);
			Variable var = ds.get(i).v;
			state.assign(var, val);
		}
		M (f.body, state);
		state.stack.pop();	*/	

    public static void main(String args[]) {
        Parser parser  = new Parser(new Lexer(args[0]));
        Program prog = parser.program();
        // prog.display();
        System.out.println("\nBegin type checking...");
        System.out.println("Type map:");
        TypeMap map = StaticTypeCheck.typing(prog.globals);
        map.display();
        StaticTypeCheck.V(prog);
        Program out = TypeTransformer.T(prog, map);
        //System.out.println("Output AST");
        // out.display();
        //Semantics semantics = new Semantics( );
        State state = M(out);
        System.out.println("Final State");
        state.display( );
	}
}
