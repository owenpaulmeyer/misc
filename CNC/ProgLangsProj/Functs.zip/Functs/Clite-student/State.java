import java.util.*;


public class State {
	Heap heap;
	Stack stack;
	Memory memory;
	FuncMap fmap;

	State(FuncMap fm){
		memory = new Memory();
		//memory.ensureCapacity(100);
		//System.out.println("size: " + memory.size());
		heap = new Heap();
		stack = new Stack();
		fmap = fm;
	}

	//creates global environment and puts it on the top of the stack
    public void allocate (Declarations ds) {
        Environment env = new Environment();
        Value intUndef = new IntValue();
        for (Declaration decl : ds){
			if (decl instanceof VariableDecl){
				VariableDecl vdec = (VariableDecl) decl;
            	env.put(vdec.v, memory.location());
				memory.add(Value.mkValue(vdec.t));
				memory.increase();
			}
			if (decl instanceof ArrayDecl){
				ArrayDecl adec = (ArrayDecl) decl;
				ArrayValue av = new ArrayValue(adec.s, adec.t, heap);
				env.put(adec.v, memory.location());
				memory.add(memory.location(), av);
				memory.increase();
			}
		}
		stack.push(env);
    }

	public void display(){
		System.out.println("heap: ");
		heap.display();
		System.out.println("globalEnv: ");
		Environment e = stack.get(0);
		e.display();
		System.out.println("mainEnv: ");
		Environment eM = stack.get(1);
		eM.display();
		System.out.println("Mems: ");
		for (int i = 0; i < memory.size(); i++){
			System.out.print("location " + i +": ");
			Value s = memory.get(i);
			System.out.println(s);
		}
	}



//intialize a Value
//Value.mkValue(vdec.t)
//new ArrayValue(adec.s, adec.t, heap)


	public void assign(Variable var, Value val){
		int loc;
		Environment e = stack.top();
		//System.out.println("stacktop "+e);
		if (e.containsKey(var)) loc = e.get(var);
		else e = stack.globes();
		//System.out.println(var);
		//System.out.println(e);
		//System.out.println("stacksize "+ stack.size());
		loc = e.get(var);
		if(var instanceof ArrayRef){
			ArrayRef ar = (ArrayRef) var;
			ArrayValue av = (ArrayValue)memory.get(loc);
			int index = Semantics.M(ar.index(), this).intValue();
			av.putValue(index, val, heap);
		}
		else {
			//System.out.println(memory.size());
			memory.set(loc, val);
		}
	}

	public Value valueOf(Variable var){
		int loc;
		Environment e = stack.top();
		if (e.containsKey(var)) loc = e.get(var);
		else e = stack.globes();
		loc = e.get(var);
		if(var instanceof ArrayRef){
			ArrayRef ar = (ArrayRef)var;
			ArrayValue av = (ArrayValue)memory.get(loc);
			int index = Semantics.M(ar.index(), this).intValue();
			return av.getValue(index, heap);
		}
		else {
			return memory.get(loc);
		}
	}
			


}

class Memory extends ArrayList<Value>{

		
	private int top = 0;

	public void write(Value v,Integer loc){
		add(loc, v);
	}

	public Value read(Integer i){
		return get(i);
	}

	public void increase(){
		top++;
	}

	public int location(){
		return top;
	}

}

class Stack extends ArrayList<Environment> {
	Integer stackPointer;
	Stack(){
		stackPointer = 0;
	}

	public void push(Environment env){
		add(env);
		stackPointer++;
	}

	public Environment pop(){
		Environment env = get(stackPointer - 1);
		stackPointer--;
		return env;
	}

	public Environment top(){
		return (get(stackPointer - 1));
	}

	public Environment globes(){
		return (get(0));
	}

}


class Environment extends HashMap<Variable, Integer>{
	public void display(){
		Set set = this.entrySet();
		Iterator i = set.iterator();
		while(i.hasNext()) { 
			Map.Entry me = (Map.Entry)i.next();
			System.out.print("Var: " + me.getKey() + " location: "); 
			System.out.println(me.getValue().toString() ); 
		}
	}
}

class Heap extends HashMap< Integer, Value > { //Integer for Address
	private Integer initialHeaderAddress = null;

	//returns the address of the allocated block's Header;
	Integer newBlock(int size){
		//allocate the first block
		if (initialHeaderAddress == null){
			Header hdr = new Header(size, -1, null);
			put(0, hdr);
			initialHeaderAddress(0);
			return 0;
		}
		//allocate a new block before the first
		else if (initialHeaderAddress > size){
			final int iha = initialHeaderAddress;
			Header hdr = new Header(size, iha, null);
			Header next = (Header)get(iha);
			next.updatePrev(0);
			//put(iha, next);
			put(0, hdr);
			initialHeaderAddress(0);
			return 0;
		}
		//iterate the heap till a spot is found or allocate at the end
		else {
			Header prevHdr = (Header)get(initialHeaderAddress);
			Integer prevHdrAddress = initialHeaderAddress;
			Integer nextFreeAddress = prevHdrAddress + prevHdr.size() + 1;
			Header hdr;
			while(true){
				//-1 signifies the end of heap; allocate at end
				if (prevHdr.nextHeader() == -1){
					prevHdr.updateNext(nextFreeAddress);
					hdr = new Header(size, -1, prevHdrAddress);
					put(nextFreeAddress, hdr);
					return nextFreeAddress;
				}
				//allocate a new block inbetween
				else if (prevHdr.nextHeader() - nextFreeAddress > size ){
					Header next = (Header)get(prevHdr.nextHeader() );
					next.updatePrev(nextFreeAddress);
						//System.out.println("*"+next);
					hdr = new Header(size, prevHdr.nextHeader(), prevHdrAddress);
					put(nextFreeAddress, hdr);
					prevHdr.updateNext(nextFreeAddress);
					return nextFreeAddress;
				}
				prevHdrAddress = prevHdr.nextHeader();
				prevHdr = (Header)get(prevHdr.nextHeader() );
				nextFreeAddress = prevHdrAddress + prevHdr.size() +1;
			}
		} 
	}

	public void deleteBlock(Integer address){
		Header hdr = (Header)get(address);
		Header next;
		Header prev;
		//delete the initialHeader
		if (hdr.prevHeader() == null){
			next = (Header)get(hdr.nextHeader() );
			next.updatePrev(null);
			initialHeaderAddress(hdr.nextHeader() );
			remove(address);
		}
		//delete the last Header
		else if (hdr.nextHeader() == -1){
			prev = (Header)get(hdr.prevHeader() );
			prev.updateNext(-1);
			remove(address);
		}
		//delete an in between Header
		else {
			next = (Header)get(hdr.nextHeader() );
			prev = (Header)get(hdr.prevHeader() );

			next.updatePrev(hdr.prevHeader() );
			prev.updateNext(hdr.nextHeader() );
			remove(address);
		}
	}

	void initialHeaderAddress(int iB){initialHeaderAddress = iB;}

	public void display(){
		Set set = this.entrySet();
		Iterator i = set.iterator();
		while(i.hasNext()) { 
			Map.Entry me = (Map.Entry)i.next();
			System.out.print("address: " + me.getKey() + "\nvalue:\n"); 
			System.out.println(me.getValue().toString()); 
		}
	}
}


class Header extends Value {
	private int size;
	private Integer nextHeader;
	private Integer prevHeader;

	Header(int s, Integer nb, Integer pb){
		size = s;
		nextHeader = nb;
		prevHeader = pb;
	}

	public int size(){return size;}

	public Integer nextHeader(){return nextHeader;}
	public Integer prevHeader(){return prevHeader;}

	public void updateNext(Integer addr){nextHeader = addr;}
	public void updatePrev(Integer addr){prevHeader = addr;}

	public String toString(){
		return "Size: "+size+"\nnextHeader: "+nextHeader+"\n"
				+"prevHeader: "+prevHeader+"\n";}
}

