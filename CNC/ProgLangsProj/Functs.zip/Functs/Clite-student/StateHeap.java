import java.util.*;


public class State {
	HashMap< String, Integer > environment; //Integer for Address
	Heap heap;
	Stack stack;




}

class Stack extends HashMap< Integer, Value > {
	private Integer stackPointer;
	private Integer framePointer;

	//no return address neccessary as sP and fP handle this
	public void push (ActivationRecord av){

	}


 

}

class Heap extends HashMap< Integer, Value > { //Integer for Address
	private Integer initialHeaderAddress = null;

	//returns the address of the allocated block's Header;
	Integer newBlock(int size){
		//allocate the first block
		if (initialHeaderAddress == null){
			Header hdr = new Header(size, -1, null);
			put(0, hdr);
			initialHeaderAddress(0);
			return 0;
		}
		//allocate a new block before the first
		else if (initialHeaderAddress > size){
			final int iha = initialHeaderAddress;
			Header hdr = new Header(size, iha, null);
			Header next = (Header)get(iha);
			next.updatePrev(0);
			//put(iha, next);
			put(0, hdr);
			initialHeaderAddress(0);
			return 0;
		}
		//iterate the heap till a spot is found or allocate at the end
		else {
			Header prevHdr = (Header)get(initialHeaderAddress);
			Integer prevHdrAddress = initialHeaderAddress;
			Integer nextFreeAddress = prevHdrAddress + prevHdr.size() + 1;
			Header hdr;
			while(true){
				//-1 signifies the end of heap; allocate at end
				if (prevHdr.nextHeader() == -1){
					prevHdr.updateNext(nextFreeAddress);
					hdr = new Header(size, -1, prevHdrAddress);
					put(nextFreeAddress, hdr);
					return nextFreeAddress;
				}
				//allocate a new block inbetween
				else if (prevHdr.nextHeader() - nextFreeAddress > size ){
					Header next = (Header)get(prevHdr.nextHeader() );
					next.updatePrev(nextFreeAddress);
						//System.out.println("*"+next);
					hdr = new Header(size, prevHdr.nextHeader(), prevHdrAddress);
					put(nextFreeAddress, hdr);
					prevHdr.updateNext(nextFreeAddress);
					return nextFreeAddress;
				}
				prevHdrAddress = prevHdr.nextHeader();
				prevHdr = (Header)get(prevHdr.nextHeader() );
				nextFreeAddress = prevHdrAddress + prevHdr.size() +1;
			}
		} 
	}

	public void deleteBlock(Integer address){
		Header hdr = (Header)get(address);
		Header next;
		Header prev;
		//delete the initialHeader
		if (hdr.prevHeader() == null){
			next = (Header)get(hdr.nextHeader() );
			next.updatePrev(null);
			initialHeaderAddress(hdr.nextHeader() );
			remove(address);
		}
		//delete the last Header
		else if (hdr.nextHeader() == -1){
			prev = (Header)get(hdr.prevHeader() );
			prev.updateNext(-1);
			remove(address);
		}
		//delete an in between Header
		else {
			next = (Header)get(hdr.nextHeader() );
			prev = (Header)get(hdr.prevHeader() );

			next.updatePrev(hdr.prevHeader() );
			prev.updateNext(hdr.nextHeader() );
			remove(address);
		}
	}

	void initialHeaderAddress(int iB){initialHeaderAddress = iB;}

	public void display(){
		Set set = this.entrySet();
		Iterator i = set.iterator();
		while(i.hasNext()) { 
			Map.Entry me = (Map.Entry)i.next();
			System.out.print("address: " + me.getKey() + "\nvalue:\n"); 
			System.out.println(me.getValue().toString()); 
		}
	}
}



