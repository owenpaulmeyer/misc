// StaticTypeCheck.java

import java.util.*;

// Static type checking for Clite is defined by the functions 
// V and the auxiliary functions typing and typeOf.  These
// functions use the classes in the Abstract Syntax of Clite.


public class StaticTypeCheck {
	//populates the TypeMap with <Variable,Type> pairs
    public static TypeMap typing (Declarations d) {
        TypeMap map = new TypeMap();
        for (Declaration di : d){
			if (di instanceof VariableDecl)
				map.put ( ((VariableDecl)di).v.toString(), (TypeOrFuncT)((VariableDecl)di).t);
			else if  (di instanceof ArrayDecl){
				map.put ( ((ArrayDecl)di).v.toString(), (TypeOrFuncT)((ArrayDecl)di).t);
			}
		}
//            map.put (di.v, di.t);
        return map;
    }


    public static TypeMap typing (Declarations locs, Declarations params, Functions fs, TypeMap globes) {
        TypeMap map = new TypeMap();
        for (Declaration di : locs){
			if (di instanceof VariableDecl)
				map.put ( ((VariableDecl)di).v.toString(), (TypeOrFuncT)((VariableDecl)di).t);
			else if  (di instanceof ArrayDecl){
				map.put ( ((ArrayDecl)di).v.toString(), (TypeOrFuncT)((ArrayDecl)di).t);
			}
		}
		for (Declaration di : params){
			if (di instanceof VariableDecl)
				map.put ( ((VariableDecl)di).v.toString(), (TypeOrFuncT)((VariableDecl)di).t);
			else if  (di instanceof ArrayDecl){
				map.put ( ((ArrayDecl)di).v.toString(), (TypeOrFuncT)((ArrayDecl)di).t);
			}
		}
/*		Object[] keys = fs.keySet().toArray();
		for (Object key : keys) {
			Function f = fs.get(key);
			TypeOrFuncT tf = new FuncT(f.t, f.params, f.locals);
			map.put ( ((Function)f).id, tf );
		}*/
		for (Function fu : fs){
			if (fu instanceof Function){
				TypeOrFuncT tf = new FuncT(fu.t, fu.params, fu.locals);
				map.put ( ((Function)fu).id, tf);
			}
		}
		map.putAll(globes);
        return map;
    }

    public static void check(boolean test, String msg) {
        if (test)  return;
        System.err.println(msg);
        System.exit(1);
    }

	public static TypeMap funcTmap (Functions f) {
		TypeMap map = new TypeMap();
/*		Object[] keys = fs.keySet().toArray();
		for (Object key : keys) {
			Function f = fs.get(key);
			TypeOrFuncT tf = new FuncT(f.t, f.params, f.locals);
			map.put ( ((Function)f).id, tf );
		}*/
		for (Function fu : f){
			if (fu instanceof Function){
				TypeOrFuncT tf = new FuncT(fu.t, fu.params, fu.locals);
				map.put ( ((Function)fu).id, tf);
			}
		}
		return map;
	}

	public static void V (Declarations d) {
        for (int i=0; i<d.size() - 1; i++)
            for (int j=i+1; j<d.size(); j++) {
                Declaration di = d.get(i);
                Declaration dj = d.get(j);
				if (di instanceof VariableDecl){
					if (dj instanceof VariableDecl)
						check( ! ( ((VariableDecl)di).v.equals( ((VariableDecl)dj).v)),
							"duplicate declaration: " + ((VariableDecl)dj).v);
					else if (dj instanceof ArrayDecl)
						check( ! ( ((VariableDecl)di).v.equals( ((ArrayDecl)dj).v)),
							"duplicate declaration: " + ((ArrayDecl)dj).v);
				}					
				if (di instanceof ArrayDecl){
					if (dj instanceof ArrayDecl)
						check( ! ( ((ArrayDecl)di).v.equals( ((ArrayDecl)dj).v)),
							"duplicate declaration: " + ((ArrayDecl)dj).v);
					else if (dj instanceof VariableDecl)
						check( ! ( ((ArrayDecl)di).v.equals( ((VariableDecl)dj).v)),
							"duplicate declaration: " + ((VariableDecl)dj).v);
				}
					
            }
    }

	 public static void V (Declarations d, Functions f) {
        for (int i=0; i<d.size() - 1; i++)
            for (int j=i+1; j<d.size(); j++)
				for (int k=0; k<f.size(); k++){
	                Declaration di = d.get(i);
	                Declaration dj = d.get(j);
					Function    fk = f.get(k);
					if (di instanceof VariableDecl){
						if (dj instanceof VariableDecl){
							check( ! ( ((VariableDecl)di).v.equals( ((VariableDecl)dj).v)),
								"duplicate declaration: " + ((VariableDecl)dj).v);
							check( !  ( ((VariableDecl)di).v.toString().equals(fk.id)),
								"dubplicated funcdelc: " + fk.id);
						}
						else if (dj instanceof ArrayDecl){
							check( ! ( ((VariableDecl)di).v.equals( ((ArrayDecl)dj).v)),
								"duplicate declaration: " + ((ArrayDecl)dj).v);
							check( !  ( ((VariableDecl)di).v.toString().equals(fk.id)),
								"dubplicated funcdelc: " + fk.id);
						}
					}					
					if (di instanceof ArrayDecl){
						if (dj instanceof ArrayDecl){
							check( ! ( ((ArrayDecl)di).v.equals( ((ArrayDecl)dj).v)),
								"duplicate declaration: " + ((ArrayDecl)dj).v);
							check( !  ( ((ArrayDecl)di).v.toString().equals(fk.id)),
								"dubplicated funcdelc: " + fk.id);
						}
						else if (dj instanceof VariableDecl){
							check( ! ( ((ArrayDecl)di).v.equals( ((VariableDecl)dj).v)),
								"duplicate declaration: " + ((VariableDecl)dj).v);
							check( !  ( ((ArrayDecl)di).v.toString().equals(fk.id)),
								"dubplicated funcdelc: " + fk.id);
						}
					}
					
            	}
    }

    public static Type typeOf (Expression e, TypeMap tm) {
        if (e instanceof Value) return ((Value)e).type;
        if (e instanceof VariableRef) {
			if (e instanceof Variable){
				Variable v = (Variable)e;
				check (tm.containsKey(v.toString()), "undefined variable: " + v);
				return (Type) tm.get(v.toString());
			}
			else if (e instanceof ArrayRef){
				//System.out.println("fetching array type");
				ArrayRef a = (ArrayRef)e;
				Type ty = (Type) tm.get(a.toString() );
				check (tm.containsKey(a.toString() ), "undefined array: " + a);
				return ty;
			}
        }
        if (e instanceof Binary) {
            Binary b = (Binary)e;
            if (b.op.ArithmeticOp( ))
                if (typeOf(b.term1,tm)== Type.FLOAT)
                    return (Type.FLOAT);
                else return (Type.INT);
            if (b.op.RelationalOp( ) || b.op.BooleanOp( )) 
                return (Type.BOOL);
        }
        if (e instanceof Unary) {
            Unary u = (Unary)e;
            if (u.op.NotOp( ))        return (Type.BOOL);
            else if (u.op.NegateOp( )) return typeOf(u.term,tm);
            else if (u.op.intOp( ))    return (Type.INT);
            else if (u.op.floatOp( )) return (Type.FLOAT);
            else if (u.op.charOp( ))  return (Type.CHAR);
        }
		if (e instanceof CallExpr){
			CallExpr ce = (CallExpr) e;
			return ((FuncT)tm.get(ce.name)).funcT;
		}

        throw new IllegalArgumentException("should never reach here");
    }

	public static void V (Program p) {
		TypeMap gtm = typing(p.globals);
		TypeMap ftm = funcTmap (p.functions);
		TypeMap vtm = new TypeMap();
		vtm.putAll(gtm);
		vtm.putAll(ftm);
        V (p.globals, p.functions);
		V (p.functions, vtm);
    }

	public static void V (Functions f, TypeMap vtm) {
        for (int i=0; i<f.size(); i++){
                Function fi = f.get(i);
				V (fi, vtm);
		}
	}

	public static void V (Function f, TypeMap tm){
		Declarations paramsLocals = new Declarations();
		paramsLocals.addAll(f.locals);
		paramsLocals.addAll(f.params);
		V (paramsLocals); //check local scope   (params, locals)
		TypeMap ltm = typing(paramsLocals);  //local TypeMap
		TypeMap vtm = new TypeMap();  //visible TypeMap
		vtm.putAll(tm);  //copies the globals
		vtm.putAll(ltm);  //onions locals onto globals

		V (f.body, vtm);
		if (f.t != Type.VOID)
			if (f.id.compareTo("main") != 0)
				check(blockReturn(f.t, f.body, vtm), "no return statement or wrong type"+f);
		else check(blockNoReturn(f.body), "void function or main with return");
	}

	//check that a return's expressions's type is correct
	private static boolean blockReturn (Type t, Block b, TypeMap tm) {
		for (Statement s : b.members){
			if (s instanceof Return){
				Return r = (Return)s;
				return t == typeOf(r.result, tm);
			}
		}
		return false;
	}

	//no return in the body of a void function
	private static boolean blockNoReturn (Block b){
		for (Statement s : b.members){
			if (s instanceof Return)
				return false;
		}
		return true;
	}
	
	




    public static void V (Expression e, TypeMap tm) {
        if (e instanceof Value) 
            return;
        if (e instanceof VariableRef) {
			if (e instanceof Variable){
				Variable v = (Variable)e;
				check( tm.containsKey(v.toString()), "undeclared variable: " + v);
				return;
			}
			else if (e instanceof ArrayRef){
				System.out.println("checking array ref.");
				ArrayRef a = (ArrayRef)e;
				check( tm.containsKey(a.toString()), "undeclared array: " + a);
				check( typeOf(a.index(),tm)==Type.INT,"non integer index value");
				V (a.index(), tm);//index expression is valid
				return;
			}
        }
        if (e instanceof Binary) {
            Binary b = (Binary) e;
            Type typ1 = typeOf(b.term1, tm);
            Type typ2 = typeOf(b.term2, tm);
            V (b.term1, tm);
            V (b.term2, tm);
            if (b.op.ArithmeticOp( )){
				//added ->
				if(typ1 == Type.FLOAT)
					check( typ2 == Type.FLOAT || typ2 == Type.INT,
								   	"type error for" + b.op);
				else if(typ1 == Type.INT)
					check( typ2 == Type.FLOAT || typ2 == Type.INT || typ2 == Type.CHAR, 
									"type error for" + b.op);
				else throw new IllegalArgumentException("type error for" + b.op);
			}
				//added <-
			/*
                check( typ1 == typ2 &&
                       (typ1 == Type.INT || typ1 == Type.FLOAT)
                       , "type error for " + b.op);
			*/
			else if (b.op.RelationalOp( )){
				//added ->
				if(typ1 == Type.FLOAT)
					check( typ2 == Type.FLOAT || typ2 == Type.INT, 
									"type error for" + b.op);
				else if(typ1 == Type.INT) //added
					check( typ2 == Type.INT || typ2 == Type.CHAR, 
									"type error for" + b.op);
				else if(typ1 == Type.CHAR)
					check(typ2 == Type.INT || typ2 == Type.CHAR, 
									"type error for" + b.op);
				else throw new IllegalArgumentException("type error for" + b.op);
			}
				//added <-

            //    check( typ1 == typ2 , "type error for " + b.op);

            else if (b.op.BooleanOp( )) 
                check( typ1 == Type.BOOL && typ2 == Type.BOOL,
                       b.op + ": non-bool operand");
            else
                throw new IllegalArgumentException("should never reach here");
            return;
        }
        // student exercise
		if (e instanceof Unary) {
			Unary u = (Unary) e;
			Type t = typeOf(u.term,tm);
			V (u.term, tm);
			if (u.op.NotOp() )
				check(typeOf(u.term,tm)==Type.BOOL,
								"Booleon Operator, NonBoolean Operand");
			else if (u.op.NegateOp() )
				check(typeOf(u.term,tm)==Type.INT || typeOf(u.term,tm)==Type.FLOAT,
								"Negate Operator, NonNumeric Operand");
			else if (u.op.charOp() || u.op.floatOp())
				check(typeOf(u.term,tm)==Type.INT,"Illegal Cast");
			else if (u.op.intOp() )
				check(typeOf(u.term,tm)==Type.CHAR || typeOf(u.term,tm)==Type.FLOAT,
								"Illegal Cast");
			return;
		}
				//student end
		if (e instanceof CallExpr){
			CallExpr ce = (CallExpr)e;
			check(typeOf(ce,tm) != Type.VOID, "void function as expression" + ce.name);
			args (ce.name, ce.args, tm); 
			return;
		}
		else throw new IllegalArgumentException("should never reach here");
    }
	
	//check a call's <argument : parameter> alignment
	private static void args (String name, Expressions args, TypeMap tm){
		Declarations params = ((FuncT)tm.get(name)).params;
		if (params.isEmpty()){
			check(args.isEmpty(),"incorrect number of arguments");
		}
		else {
			check(params.size() == args.size(), "incorrect number of arguments");
			for (int i = 0; i < args.size(); i++){
				Declaration p = params.get(i);
				Expression e  = args.get(i);
				check(typeOf(e, tm) == p.t, "types of arguments and parameters do not line up");
			}
		}
	}
	

    public static void V (Statement s, TypeMap tm) {
        if ( s == null )
            throw new IllegalArgumentException( "AST error: null statement");
        if (s instanceof Skip) return;
		if (s instanceof Return) return;
		if (s instanceof CallStmt){
			CallStmt cs = (CallStmt) s;
			check(tm.containsKey(cs.name),"undefined function call statemtent");
			args (cs.name, cs.args, tm); 
			Type ft = ((FuncT)tm.get(cs.name)).funcT;
			//check(ft == Type.VOID, "non void call statement");
			return;
		}

        if (s instanceof Assignment) {
			//tm.display();
            Assignment a = (Assignment)s;
			if (a.target instanceof ArrayRef){
				//System.out.println("checking array ref: "+ a.target.toString());
				check(tm.containsKey(((ArrayRef)a.target).toString()),
					"undefined Atarget in assignment:" + a.target.toString());
				V (a.target,tm);
			}
			else if (a.target instanceof Variable){
				//System.out.println("check variable ref: "+a.target.toString());
				check( tm.containsKey(a.target.toString())
                   , " undefined Vtarget in assignment: " + a.target);
			}
			
            V(a.source, tm);
            Type ttype = (Type)tm.get(a.target.toString() );
            Type srctype = typeOf(a.source, tm);
            if (ttype != srctype) {
                if (ttype == Type.FLOAT)
                    check( srctype == Type.INT
                           , "mixed mode assignment to " + a.target);
                else if (ttype == Type.INT)
                    check( srctype == Type.CHAR
                           , "mixed mode assignment to " + a.target);
                else
                    check( false
                           , "mixed mode assignment to " + a.target);
            }
            return;
        } 
        // student exercise
		if (s instanceof Conditional){
			//System.out.println("Looking at Conditional.");
			Conditional c = (Conditional) s;
			V(c.test, tm);
			check(typeOf(c.test, tm)==Type.BOOL,"NonBoolean Test Expression.");
			V (c.thenbranch, tm);
			V (c.elsebranch, tm);
			return;
		}
		if (s instanceof Loop){
			//System.out.println("Looking at Loop.");
			Loop l = (Loop) s;
			V (l.test, tm);
			check(typeOf(l.test, tm)==Type.BOOL,"NonBoolean Test Expression.");
			V (l.body, tm);
			return;
		}
		if (s instanceof Block){
			//System.out.println("Looking at Block.");
			Block b = (Block) s;
			for (Statement stm : b.members){
				V (stm, tm);
			}
			return;
		}
		
		// exercise end
		else throw new IllegalArgumentException("should never reach here");
    }

    public static void main(String args[]) {
        Parser parser  = new Parser(new Lexer(args[0]));
        Program prog = parser.program();
        // prog.display();           // student exercise
        System.out.println("\nBegin type checking...");
        System.out.println("Type map:");
        TypeMap map = typing(prog.globals);
		map.putAll(funcTmap(prog.functions));
        map.display();   // student exercise
		//V(prog.decpart);
        V(prog);
    } //main

} // class StaticTypeCheck

