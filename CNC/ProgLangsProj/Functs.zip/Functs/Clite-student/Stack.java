import java.util.*;


class Stack extends ArrayList<State> {}
