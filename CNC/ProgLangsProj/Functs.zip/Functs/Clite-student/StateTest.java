public class StateTest{

public static void main(String args[]) {
	Heap heap = new Heap();
	System.out.println("first: " +heap.newBlock(4));
	//heap.display();
	System.out.println("snd: " +heap.newBlock(7));
	//heap.display();
	System.out.println("thrd: " +heap.newBlock(3));
	//heap.display();
	System.out.println("fourf: " +heap.newBlock(2));
	heap.deleteBlock(5);
	heap.deleteBlock(17);
	heap.display();
	System.out.println("fifth: "+heap.newBlock(3));
	System.out.println("sixth: "+heap.newBlock(3));
	System.out.println("sevnt: "+heap.newBlock(4));


	
	System.out.println("\nresults:\n");
	heap.display();
    } //main
}
