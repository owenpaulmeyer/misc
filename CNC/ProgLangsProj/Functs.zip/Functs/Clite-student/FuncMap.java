import java.util.*;

public class FuncMap extends HashMap<String, Function> { 


public void display(){
	Set set = this.entrySet();
	Iterator i = set.iterator();
	while(i.hasNext()) { 
		Map.Entry me = (Map.Entry)i.next();
		System.out.print("Identifier: " + me.getKey() + " type: "); 
		System.out.println(me.getValue().toString() ); 
	}
}
}
