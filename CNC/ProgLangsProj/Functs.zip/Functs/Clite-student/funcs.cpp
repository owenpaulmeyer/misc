int hasp (int twisp){
	int r;
	r = twisp * twisp;
	return r;
}

 
int rat, flat;

int main () {
	int jax;
	rat = 8;
	flat = hasp(rat);
}
