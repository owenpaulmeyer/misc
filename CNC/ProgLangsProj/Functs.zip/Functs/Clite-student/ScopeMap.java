import java.util.*;

public class ScopeMap extends ArrayList<TypeMap>{}
