import java.util.*;

public class ScopeTest {
	public static void main (String args[]) {
		HashMap<String, Integer> hm1 = new HashMap<String, Integer>();
		HashMap<String, Integer> hm2 = new HashMap<String, Integer>();
		hm1.put("ron", 12);
		hm1.put("tron", 5);
		hm2.put("ton", 1);
		hm2.put("tron", 1);
		hm1.putAll(hm2);
		System.out.println(hm1);
		System.out.println(hm2);

	}
}	
