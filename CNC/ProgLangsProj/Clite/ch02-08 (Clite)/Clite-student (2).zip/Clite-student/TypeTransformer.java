import java.util.*;

public class TypeTransformer {

    public static Program T (Program p, TypeMap tm) {
        Block body = (Block)T(p.body, tm);
        return new Program(p.decpart, body);
    } 

    public static Expression T (Expression e, TypeMap tm) {
        if (e instanceof Value) 
            return e;
        if (e instanceof VariableRef){
			if (e instanceof ArrayRef){
				ArrayRef ar = (ArrayRef)e;
				ar.setIndex(T (ar.index(), tm));
				e = (Expression)ar;
				System.out.println("setting source index");
				return e;
			}
			else if (e instanceof Variable)
				return e;
		}
        if (e instanceof Binary) {
            Binary b = (Binary)e; 
            Type typ1 = StaticTypeCheck.typeOf(b.term1, tm);
            Type typ2 = StaticTypeCheck.typeOf(b.term2, tm);
            Expression t1 = T (b.term1, tm);
            Expression t2 = T (b.term2, tm);
            if (typ1 == Type.INT){
				if (typ2 == Type.FLOAT)
					return new Binary(b.op.intMap(b.op.val),t1,
							new Unary(Operator.floatMap(Operator.INT),t2));
				else if (typ2 == Type.INT)
                	return new Binary(b.op.intMap(b.op.val), t1,t2);
				else if (typ2 == Type.CHAR)
					return new Binary(b.op.intMap(b.op.val), t1,
							new Unary(Operator.charMap(Operator.INT),t2) );
			}
            else if (typ1 == Type.FLOAT){
				if (typ2 == Type.FLOAT)
                	return new Binary(b.op.floatMap(b.op.val), t1,t2);
				else if (typ2 == Type.INT)
					return new Binary(b.op.floatMap(b.op.val), t1,
							new Unary(Operator.intMap(Operator.FLOAT),t2) );
			}
            else if (typ1 == Type.CHAR){
				if (typ2 == Type.CHAR)
                	return new Binary(b.op.charMap(b.op.val), t1,t2);
				else if (typ2 == Type.INT)
					return new Binary(b.op.charMap(b.op.val), t1,
							new Unary(Operator.intMap(Operator.CHAR), t2));
			}
            else if (typ1 == Type.BOOL) 
                return new Binary(b.op.boolMap(b.op.val), t1,t2);
            throw new IllegalArgumentException("should never reach here");
		}
		// student exercise begin
		if (e instanceof Unary){
			Unary u = (Unary) e;
			Type typ = StaticTypeCheck.typeOf(u.term, tm);
			Expression t = T (u.term, tm);
			if (typ == Type.INT)
				return new Unary(u.op.intMap(u.op.val), t);
			else if (typ == Type.FLOAT)
				return new Unary(u.op.floatMap(u.op.val), t);
			else if (typ == Type.CHAR)
				return new Unary(u.op.charMap(u.op.val), t);
			else if (typ == Type.BOOL)
				return u;// new Unary(new Operator(Operator.NOT), t);
			else throw new IllegalArgumentException("unary dissillusion");	
		}
        // student exercise end
        throw new IllegalArgumentException("should never reach here!!");
    }

    public static Statement T (Statement s, TypeMap tm) {
        if (s instanceof Skip) return s;
        if (s instanceof Assignment) {
            Assignment a = (Assignment)s;
			VariableRef target = null;
			if (a.target instanceof Variable)
				target = (Variable)a.target;
			if (a.target instanceof ArrayRef){
				ArrayRef targ = (ArrayRef)a.target;
				targ.setIndex(T (targ.index(), tm));
				target = (VariableRef)targ;
			}
			Expression src = T (a.source, tm);
			Type ttype = (Type)tm.get(a.target);
			Type srctype = StaticTypeCheck.typeOf(a.source, tm);
            if (ttype == Type.FLOAT) {
                if (srctype == Type.INT) {
                    src = new Unary(new Operator(Operator.I2F), src);
                    srctype = Type.FLOAT;
                }
            }
            else if (ttype == Type.INT) {
                if (srctype == Type.CHAR) {
                    src = new Unary(new Operator(Operator.C2I), src);
                    srctype = Type.INT;
                }
            }
            StaticTypeCheck.check( ttype == srctype,
                      "bug in assignment to " + target);
            return new Assignment(target, src);
        } 
        if (s instanceof Conditional) {
            Conditional c = (Conditional)s;
            Expression test = T (c.test, tm);
            Statement tbr = T (c.thenbranch, tm);
            Statement ebr = T (c.elsebranch, tm);
            return new Conditional(test,  tbr, ebr);
        }
        if (s instanceof Loop) {
            Loop l = (Loop)s;
            Expression test = T (l.test, tm);
            Statement body = T (l.body, tm);
            return new Loop(test, body);
        }
        if (s instanceof Block) {
            Block b = (Block)s;
            Block out = new Block();
            for (Statement stmt : b.members)
                out.members.add(T(stmt, tm));
            return out;
        }
        throw new IllegalArgumentException("should never reach here");
    }
    

    public static void main(String args[]) {
        Parser parser  = new Parser(new Lexer(args[0]));
        Program prog = parser.program();
        // prog.display();           // student exercise
        System.out.println("\nBegin type checking...");
        System.out.println("Type map:");
        TypeMap map = StaticTypeCheck.typing(prog.decpart);
        // map.display();    // student exercise
        StaticTypeCheck.V(prog);
        Program out = T(prog, map);
        System.out.println("Output AST");
         out.display();    // student exercise
    } //main

    } // class TypeTransformer

    
