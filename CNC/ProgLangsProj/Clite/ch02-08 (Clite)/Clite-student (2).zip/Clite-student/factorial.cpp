int main ( ) {
    int n, i, f, c,put;
	int fa[11];
	put = 1;
	c = 0;
    n = 3;
    i = 1;
    f = 1;
    while (i < n) {
        i = i + 1;
        f = f * i;
    }
	fa[c] = put;
	fa[c+1] = put;
	c = 2;
	while (c < 11){
		fa[c] = fa[c-1] + fa[c-2];
		c = c+1;
	}
	//fa[2] = fa[12];
}
