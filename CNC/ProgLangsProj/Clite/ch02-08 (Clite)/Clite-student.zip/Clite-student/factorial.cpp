int main ( ) {
    int n, i, f;
	float fa[5];

	char t;
    n = 3;
    i = 1;
    f = 1;
	fa[4] = n+fa[2];
    while (i < n) {
        i = i + 1;
        f = f * i;
    }
	t = 'y';
}
