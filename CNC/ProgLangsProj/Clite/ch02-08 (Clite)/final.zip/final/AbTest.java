public class AbTest{

public static void main(String args[]) {
		Type t = Type.FLOAT;
		t = Type.BOOL;
		t = Type.INT;
		//Type n = Type.FLOAT;
		//Type d = Type.BOOL;
        //Value v = Value.mkValue(Type.BOOL);
		//System.out.print("here:  ");
		//System.out.println(v.type());
		System.out.println("test:  "+ t);
    } //main
}
