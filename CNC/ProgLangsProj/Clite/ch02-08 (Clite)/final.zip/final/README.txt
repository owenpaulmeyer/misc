CNC 2012
Programming Languages Project
Professor Neal Nelson
Fall Quarter results
OwenMeyer

Here is my Clite project up through TypeTransformer.  I also implemented arrays up to this point.  factorial.output shows the result of running the Transformer on factorial.cpp (from the command line: java TypeTransformer factorial.cpp).  The factorial.cpp represented here is no longer a sensical factorial program, but a hodgepodge thrown in to test out the TypeTransformer and arrays.  I also implemented implicit type conversions for chars to ints and ints to floats.  Thankyou for a fantastic quarter, and tolerating my personality. Cheers and have a great intermission.
