CnC 2012
Haskell
Professor Neal Nelson
Homework 5 abstract syntax for Clite
Owen Meyer

To view the results of an abstract syntax tree displayed in a stylized format, load cliteParser.hs into GHCi from this directory and type: 
showit (parse program clone)          --for clone.cpp
showit (parse program factorial)      --for factorial.cpp


